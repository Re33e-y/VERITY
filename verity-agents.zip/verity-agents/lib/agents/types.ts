// lib/agents/types.ts
// Shared types for Verity's agentic review layer.

export type Policy = "auto" | "thorough" | "off";
export type Grade = "A" | "B" | "C";
export type SpecialistKind = "tone" | "fact" | "legal";

export interface Span {
  start: number;
  end: number;
}
export interface FocusSentence extends Span {
  text: string;
}

// ---- Brand Canon (as the agents see it; map your DB rows in adapters.ts) ----
export interface CanonRule {
  id: string;
  category: string;
  text: string;
  /** Approved replacement term/phrase, if the rule has one (banned term -> approved term). */
  replacement?: string | null;
}
export interface CanonFact {
  id: string;
  text: string;
  keywords?: string[];
  valid_until?: string | null;
}
export interface Canon {
  version: string;
  rules: CanonRule[];
  facts: CanonFact[];
}

export interface Citation {
  type: "rule" | "fact";
  id: string;
}

// ---- Remediation ----
export interface Patch {
  start: number;
  end: number;
  original: string;
  replacement: string;
  rationale: string;
  origin: "canon" | "panel" | "critic" | "retry";
  /** True only if the offline engine no longer flags the patched span. */
  verified: boolean;
  verification: string;
}

// ---- Findings ----
export interface Finding extends Span {
  /** In-flight id. Your persistence layer should keep assigning real UUIDs. */
  id: string;
  quote: string;
  category: string;
  grade: Grade;
  /** "rule" | "offline" | "agent:tone" | "agent:fact" | "agent:legal" */
  source: string;
  explanation: string;
  suggestion?: string | null;
  citations: Citation[];
  confidence?: number;
  notes?: string[];
  patch?: Patch;
  /** Internal: replacement proposed by an agent, consumed by remediation, stripped before returning. */
  draftFix?: string | null;
}

export interface Suppressed {
  finding: Finding;
  reason: string;
  by: "critic";
}

export type OfflineFn = (text: string, canon: Canon) => Finding[] | Promise<Finding[]>;

// ---- Orchestration ----
export interface Plan {
  engage: boolean;
  reason: string;
  policy: Policy;
  maxCalls: number;
  focus: FocusSentence[];
  specialists: SpecialistKind[];
  /** How specialists are packed into LLM calls under the budget. */
  groups: SpecialistKind[][];
  critic: boolean;
  /** Enables the self-correction loop (critic recheck) and remediation retry. */
  loop: boolean;
}

export interface TraceStep {
  agent: string;
  kind: "plan" | "llm" | "guard" | "verify" | "cache" | "skip";
  ok: boolean;
  calls: number;
  ms: number;
  detail: string;
}

export interface AgenticResult {
  findings: Finding[];
  suppressed: Suppressed[];
  status: "skipped" | "agentic" | "degraded";
  /** True only when AI review was needed and no model call succeeded. Withhold the score, as you do today. */
  ai_unavailable: boolean;
  warnings: string[];
  calls_used: number;
  cache_hit: boolean;
  plan: Plan;
  trace: TraceStep[];
}

export interface CacheAdapter {
  get(key: string): Promise<AgenticResult | null>;
  set(key: string, value: AgenticResult): Promise<void>;
}
