// lib/agents/adapters.ts
// The ONLY file that knows your existing shapes. I wrote it against the README, not your source,
// so the field-name fallbacks below are guesses. Edit the `pick([...])` key lists to match
// lib/engine/offline.ts and your rules/facts tables; nothing else in lib/agents needs to change.

import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { AgenticResult, CacheAdapter, Canon, CanonFact, CanonRule, Citation, Finding, Grade } from "./types";

type Row = Record<string, unknown>;
const pick = (o: Row, keys: string[]): unknown => {
  for (const k of keys) if (o[k] !== undefined && o[k] !== null && o[k] !== "") return o[k];
  return undefined;
};
const str = (v: unknown, d = ""): string => (v === undefined || v === null ? d : String(v));

let _db: SupabaseClient | null = null;
function db(): SupabaseClient {
  // Swap for your existing server-side client helper if you have one.
  return (_db ??= createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false },
  }));
}

// ---------------------------------------------------------------- canon
export function toAgentCanon(raw: { version?: unknown; rules?: Row[]; facts?: Row[] }): Canon {
  const rules: CanonRule[] = (raw.rules ?? []).map((r) => ({
    id: str(pick(r, ["code", "rule_id", "id"])),
    category: str(pick(r, ["category", "type", "kind"]), "rule"),
    text: str(pick(r, ["text", "description", "rule", "statement"])),
    // Approved replacement term, if your rules carry one (banned term -> approved term).
    replacement: (pick(r, ["replacement", "approved_term", "replace_with"]) as string | undefined) ?? null,
  }));
  const facts: CanonFact[] = (raw.facts ?? []).map((f) => ({
    id: str(pick(f, ["code", "fact_id", "id"])),
    text: str(pick(f, ["text", "statement", "claim", "fact"])),
    keywords: Array.isArray(f.keywords) ? (f.keywords as unknown[]).map(String) : undefined,
    valid_until: (pick(f, ["valid_until", "expires_at", "expiry", "expires"]) as string | undefined) ?? null,
  }));
  return { version: str(raw.version ?? "1"), rules, facts };
}

// ---------------------------------------------------------------- findings
const toGrade = (v: unknown): Grade => (v === "A" || v === "B" || v === "C" ? v : "C");

/**
 * Create one mapper per review. It remembers each original finding so that fields the agents know
 * nothing about (your rule_id, severity, etc.) survive the round trip.
 */
export function makeFindingMapper() {
  const originals = new Map<string, Row>();
  let n = 0;
  return {
    to(raw: Row): Finding {
      const span = (raw.span ?? {}) as Row;
      const start = Number(pick(raw, ["start", "start_offset", "offset_start"]) ?? span.start ?? 0);
      const end = Number(pick(raw, ["end", "end_offset", "offset_end"]) ?? span.end ?? start);
      const id = str(raw.id, `o_${start}_${end}_${n++}`);
      originals.set(id, raw);

      const citations: Citation[] = Array.isArray(raw.citations)
        ? (raw.citations as Citation[])
        : [
            ...(raw.rule_id ? [{ type: "rule" as const, id: str(raw.rule_id) }] : []),
            ...(raw.fact_id ? [{ type: "fact" as const, id: str(raw.fact_id) }] : []),
          ];
      return {
        id, start, end,
        quote: str(pick(raw, ["quote", "text", "matched_text", "span_text"])),
        category: str(pick(raw, ["category", "type", "label"]), "Unsupported"),
        grade: toGrade(pick(raw, ["grade", "evidence_grade"])),
        source: str(raw.source, "offline"),
        explanation: str(pick(raw, ["explanation", "reason", "message"])),
        suggestion: (pick(raw, ["suggestion", "suggested_correction", "fix"]) as string | undefined) ?? null,
        citations,
      };
    },
    /** Back to a plain row. Original fields are kept; agent-owned fields are layered on top. */
    from(f: Finding): Row {
      const orig = originals.get(f.id) ?? {};
      return {
        ...orig,
        start: f.start, end: f.end, quote: f.quote,
        category: f.category, grade: f.grade, source: f.source,
        explanation: f.explanation, suggestion: f.suggestion ?? orig.suggestion ?? null,
        citations: f.citations,
        ai_notes: f.notes ?? [],
        patch: f.patch ?? null,
      };
    },
  };
}

// ---------------------------------------------------------------- cache (llm_cache table from your migration)
const TTL_MS = (Number(process.env.AGENT_CACHE_TTL_HOURS) || 24) * 3_600_000;

export function supabaseCache(): CacheAdapter {
  return {
    async get(key) {
      const { data, error } = await db().from("llm_cache").select("payload, expires_at").eq("cache_key", key).maybeSingle();
      if (error || !data) return null;
      if (new Date(String(data.expires_at)).getTime() <= Date.now()) return null; // expired = miss
      return data.payload as AgenticResult;
    },
    async set(key, value) {
      await db()
        .from("llm_cache")
        .upsert(
          { cache_key: key, payload: value, kind: "agentic", expires_at: new Date(Date.now() + TTL_MS).toISOString() },
          { onConflict: "cache_key" },
        );
    },
  };
}

// ---------------------------------------------------------------- trace persistence
export async function persistTrace(reviewRunId: string, r: AgenticResult): Promise<{ ok: boolean; reason?: string }> {
  const { error } = await db().from("agent_traces").insert({
    review_run_id: reviewRunId,
    status: r.status,
    policy: r.plan.policy,
    calls_used: r.calls_used,
    cache_hit: r.cache_hit,
    plan: r.plan,
    trace: r.trace,
    suppressed: r.suppressed,
    warnings: r.warnings,
  });
  return error ? { ok: false, reason: error.message } : { ok: true };
}
